package com.example.harlemlauncher

import android.animation.Animator
import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.random.Random

data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: Drawable,
    val launchIntent: Intent
)

class MainActivity : AppCompatActivity() {

    private lateinit var grid: RecyclerView
    private lateinit var root: View
    private lateinit var shakeButton: Button

    private val handler = Handler(Looper.getMainLooper())
    private val animators = mutableListOf<Animator>()
    private var player: MediaPlayer? = null
    private var shaking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        grid = findViewById(R.id.appGrid)
        shakeButton = findViewById(R.id.shakeButton)

        grid.layoutManager = GridLayoutManager(this, 4)
        grid.adapter = AppAdapter(loadApps()) { app -> startActivity(app.launchIntent) }

        shakeButton.setOnClickListener {
            if (shaking) stopShake() else startShake()
        }

        // Лаунчер не должен закрываться кнопкой «назад»
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (shaking) stopShake()
            }
        })
    }

    private fun loadApps(): List<AppInfo> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val launch = pm.getLaunchIntentForPackage(it.activityInfo.packageName)
                    ?: Intent(Intent.ACTION_MAIN).setClassName(
                        it.activityInfo.packageName, it.activityInfo.name
                    )
                AppInfo(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    icon = it.loadIcon(pm),
                    launchIntent = launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    // ---------------- Harlem Shake ----------------

    private fun startShake() {
        shaking = true
        shakeButton.setText(R.string.stop_button)
        startMusicIfPresent()

        val children = (0 until grid.childCount).map { grid.getChildAt(it) }
        if (children.isEmpty()) return

        // Фаза 1: танцует один в одиночестве (~4 сек)
        dance(children.random(), strength = 1f)

        // Фаза 2: «дроп» — все срываются с цепи
        handler.postDelayed({
            if (!shaking) return@postDelayed
            children.forEach { dance(it, strength = 1.6f) }
            flashBackground()
        }, 4000)

        // Автоостановка
        handler.postDelayed({ stopShake() }, 4000 + 12000)
    }

    private fun dance(view: View, strength: Float) {
        val rot = ObjectAnimator.ofFloat(
            view, View.ROTATION, -25f * strength, 25f * strength
        ).apply {
            duration = Random.nextLong(120, 260)
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
            interpolator = LinearInterpolator()
        }
        val jump = ObjectAnimator.ofFloat(
            view, View.TRANSLATION_Y, 0f, -40f * strength
        ).apply {
            duration = Random.nextLong(150, 300)
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
        }
        val sx = ObjectAnimator.ofFloat(view, View.SCALE_X, 1f, 1f + 0.35f * strength).apply {
            duration = Random.nextLong(150, 300)
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
        }
        val sy = ObjectAnimator.ofFloat(view, View.SCALE_Y, 1f, 1f + 0.35f * strength).apply {
            duration = sx.duration
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
        }
        listOf(rot, jump, sx, sy).forEach {
            animators.add(it)
            it.start()
        }
    }

    private fun flashBackground() {
        val colors = intArrayOf(
            Color.argb(120, 255, 0, 128), Color.argb(120, 0, 200, 255),
            Color.argb(120, 255, 230, 0), Color.argb(120, 120, 255, 0)
        )
        val flash = object : Runnable {
            override fun run() {
                if (!shaking) return
                root.setBackgroundColor(colors.random())
                handler.postDelayed(this, 150)
            }
        }
        handler.post(flash)
    }

    private fun stopShake() {
        shaking = false
        handler.removeCallbacksAndMessages(null)
        animators.forEach { it.cancel() }
        animators.clear()
        for (i in 0 until grid.childCount) {
            grid.getChildAt(i).apply {
                rotation = 0f; translationY = 0f; scaleX = 1f; scaleY = 1f
            }
        }
        root.setBackgroundColor(Color.TRANSPARENT)
        shakeButton.setText(R.string.shake_button)
        player?.release()
        player = null
    }

    /** Если положить свой трек в res/raw/harlem.mp3 — он будет играть. */
    private fun startMusicIfPresent() {
        val resId = resources.getIdentifier("harlem", "raw", packageName)
        if (resId != 0) {
            player = MediaPlayer.create(this, resId)?.also { it.start() }
        }
    }

    override fun onStop() {
        super.onStop()
        if (shaking) stopShake()
    }

    // ---------------- Adapter ----------------

    private class AppAdapter(
        private val apps: List<AppInfo>,
        private val onClick: (AppInfo) -> Unit
    ) : RecyclerView.Adapter<AppAdapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.appIcon)
            val label: TextView = v.findViewById(R.id.appLabel)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

        override fun onBindViewHolder(holder: VH, position: Int) {
            val app = apps[position]
            holder.icon.setImageDrawable(app.icon)
            holder.label.text = app.label
            holder.itemView.setOnClickListener { onClick(app) }
        }

        override fun getItemCount() = apps.size
    }
}
